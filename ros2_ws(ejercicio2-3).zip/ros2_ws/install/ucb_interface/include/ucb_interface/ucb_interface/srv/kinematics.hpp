// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef UCB_INTERFACE__SRV__KINEMATICS_HPP_
#define UCB_INTERFACE__SRV__KINEMATICS_HPP_

#include "ucb_interface/srv/detail/kinematics__struct.hpp"
#include "ucb_interface/srv/detail/kinematics__builder.hpp"
#include "ucb_interface/srv/detail/kinematics__traits.hpp"
#include "ucb_interface/srv/detail/kinematics__type_support.hpp"

#endif  // UCB_INTERFACE__SRV__KINEMATICS_HPP_
