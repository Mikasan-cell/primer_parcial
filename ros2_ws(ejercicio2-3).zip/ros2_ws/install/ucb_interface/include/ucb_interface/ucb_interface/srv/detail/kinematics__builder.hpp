// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from ucb_interface:srv/Kinematics.idl
// generated code does not contain a copyright notice

#ifndef UCB_INTERFACE__SRV__DETAIL__KINEMATICS__BUILDER_HPP_
#define UCB_INTERFACE__SRV__DETAIL__KINEMATICS__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "ucb_interface/srv/detail/kinematics__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace ucb_interface
{

namespace srv
{

namespace builder
{

class Init_Kinematics_Request_theta4
{
public:
  explicit Init_Kinematics_Request_theta4(::ucb_interface::srv::Kinematics_Request & msg)
  : msg_(msg)
  {}
  ::ucb_interface::srv::Kinematics_Request theta4(::ucb_interface::srv::Kinematics_Request::_theta4_type arg)
  {
    msg_.theta4 = std::move(arg);
    return std::move(msg_);
  }

private:
  ::ucb_interface::srv::Kinematics_Request msg_;
};

class Init_Kinematics_Request_theta3
{
public:
  explicit Init_Kinematics_Request_theta3(::ucb_interface::srv::Kinematics_Request & msg)
  : msg_(msg)
  {}
  Init_Kinematics_Request_theta4 theta3(::ucb_interface::srv::Kinematics_Request::_theta3_type arg)
  {
    msg_.theta3 = std::move(arg);
    return Init_Kinematics_Request_theta4(msg_);
  }

private:
  ::ucb_interface::srv::Kinematics_Request msg_;
};

class Init_Kinematics_Request_theta2
{
public:
  explicit Init_Kinematics_Request_theta2(::ucb_interface::srv::Kinematics_Request & msg)
  : msg_(msg)
  {}
  Init_Kinematics_Request_theta3 theta2(::ucb_interface::srv::Kinematics_Request::_theta2_type arg)
  {
    msg_.theta2 = std::move(arg);
    return Init_Kinematics_Request_theta3(msg_);
  }

private:
  ::ucb_interface::srv::Kinematics_Request msg_;
};

class Init_Kinematics_Request_theta1
{
public:
  Init_Kinematics_Request_theta1()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_Kinematics_Request_theta2 theta1(::ucb_interface::srv::Kinematics_Request::_theta1_type arg)
  {
    msg_.theta1 = std::move(arg);
    return Init_Kinematics_Request_theta2(msg_);
  }

private:
  ::ucb_interface::srv::Kinematics_Request msg_;
};

}  // namespace builder

}  // namespace srv

template<typename MessageType>
auto build();

template<>
inline
auto build<::ucb_interface::srv::Kinematics_Request>()
{
  return ucb_interface::srv::builder::Init_Kinematics_Request_theta1();
}

}  // namespace ucb_interface


namespace ucb_interface
{

namespace srv
{

namespace builder
{

class Init_Kinematics_Response_pose
{
public:
  Init_Kinematics_Response_pose()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  ::ucb_interface::srv::Kinematics_Response pose(::ucb_interface::srv::Kinematics_Response::_pose_type arg)
  {
    msg_.pose = std::move(arg);
    return std::move(msg_);
  }

private:
  ::ucb_interface::srv::Kinematics_Response msg_;
};

}  // namespace builder

}  // namespace srv

template<typename MessageType>
auto build();

template<>
inline
auto build<::ucb_interface::srv::Kinematics_Response>()
{
  return ucb_interface::srv::builder::Init_Kinematics_Response_pose();
}

}  // namespace ucb_interface

#endif  // UCB_INTERFACE__SRV__DETAIL__KINEMATICS__BUILDER_HPP_
