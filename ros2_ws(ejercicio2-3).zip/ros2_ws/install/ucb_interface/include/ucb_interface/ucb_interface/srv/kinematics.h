// generated from rosidl_generator_c/resource/idl.h.em
// with input from ucb_interface:srv/Kinematics.idl
// generated code does not contain a copyright notice

#ifndef UCB_INTERFACE__SRV__KINEMATICS_H_
#define UCB_INTERFACE__SRV__KINEMATICS_H_

#include "ucb_interface/srv/detail/kinematics__struct.h"
#include "ucb_interface/srv/detail/kinematics__functions.h"
#include "ucb_interface/srv/detail/kinematics__type_support.h"

#endif  // UCB_INTERFACE__SRV__KINEMATICS_H_
