// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef UCB_INTERFACE__MSG__NUM_HPP_
#define UCB_INTERFACE__MSG__NUM_HPP_

#include "ucb_interface/msg/detail/num__struct.hpp"
#include "ucb_interface/msg/detail/num__builder.hpp"
#include "ucb_interface/msg/detail/num__traits.hpp"
#include "ucb_interface/msg/detail/num__type_support.hpp"

#endif  // UCB_INTERFACE__MSG__NUM_HPP_
