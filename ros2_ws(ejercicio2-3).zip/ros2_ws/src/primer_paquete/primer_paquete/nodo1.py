import rclpy
from rclpy.node import Node
from std_msgs.msg import Float64
import random

class Sensor1Publisher(Node):
    def __init__(self):
        super().__init__('Nodo1')  # Nombre del nodo
        self.publisher = self.create_publisher(Float64, 'sensor_1', 10)  # Publicador en el tópico "sensor_1"
        self.timer = self.create_timer(3.0, self.publish_sensor_data)  # Temporizador cada 1 seg

    def publish_sensor_data(self):
        msg = Float64()
        msg.data = round(random.uniform(0.0, 10.0), 1)  # Genera un número flotante entre 0 y 10
        self.publisher.publish(msg)
        self.get_logger().info(f'[Sensor 1] Publicando: {msg.data}')

def main(args=None):
    rclpy.init(args=args)
    sensor1 = Sensor1Publisher()
    rclpy.spin(sensor1)
    sensor1.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()