import rclpy
from rclpy.node import Node
from std_msgs.msg import Float64
from ucb_interface.msg import Num  # Importamos nuestra interfaz personalizada

class SensorFilter(Node):
    def __init__(self):
        super().__init__('Nodo4')

        # Suscribirse a los 3 sensores
        self.sub_1 = self.create_subscription(Float64, 'sensor_1', self.sensor1_callback, 10)
        self.sub_2 = self.create_subscription(Float64, 'sensor_2', self.sensor2_callback, 10)
        self.sub_3 = self.create_subscription(Float64, 'sensor_3', self.sensor3_callback, 10)

        # Publicador en el nuevo tópico /filtered_sensor
        self.publisher = self.create_publisher(Num, 'filtered_sensor', 10)

        # Temporizador para publicar el promedio cada 1 segundo
        self.timer = self.create_timer(1.0, self.publish_filtered_data)

        # Variables para almacenar los datos de los sensores
        self.values = {'sensor_1': None, 'sensor_2': None, 'sensor_3': None}

    def sensor1_callback(self, msg):
        self.values['sensor_1'] = msg.data

    def sensor2_callback(self, msg):
        self.values['sensor_2'] = msg.data

    def sensor3_callback(self, msg):
        self.values['sensor_3'] = msg.data

    def publish_filtered_data(self):
        # Solo publica si ya tiene datos de los 3 sensores
        if None not in self.values.values():
            avg = round(sum(self.values.values()) / len(self.values), 1)  # Promedio con 1 decimal

            # Crear mensaje personalizado
            msg = Num()
            msg.value = avg
            msg.name = "Filtered Sensor"

            # Publicar el mensaje
            self.publisher.publish(msg)
            self.get_logger().info(f'Publicando Promedio: {avg}')

def main(args=None):
    rclpy.init(args=args)
    sensor_filter = SensorFilter()
    rclpy.spin(sensor_filter)
    sensor_filter.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()