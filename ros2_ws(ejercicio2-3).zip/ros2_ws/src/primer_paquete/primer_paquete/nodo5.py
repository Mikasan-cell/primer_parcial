import rclpy
from rclpy.node import Node
from ucb_interface.msg import Num  # Importamos la interfaz personalizada

class SensorMonitor(Node):
    def __init__(self):
        super().__init__('Nodo5')

        # Suscribirse al tópico /filtered_sensor
        self.subscription = self.create_subscription(
            Num, 'filtered_sensor', self.callback, 10)
        self.subscription  # Mantener la suscripción activa

    def callback(self, msg):
        self.get_logger().info(f'Valor Promediado Recibido: {msg.value}')

def main(args=None):
    rclpy.init(args=args)
    sensor_monitor = SensorMonitor()
    rclpy.spin(sensor_monitor)
    sensor_monitor.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()