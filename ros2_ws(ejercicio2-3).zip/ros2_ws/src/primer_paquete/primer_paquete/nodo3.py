import rclpy
from rclpy.node import Node
from std_msgs.msg import Float64
import random

class Sensor3Publisher(Node):
    def __init__(self):
        super().__init__('Nodo3')
        self.publisher = self.create_publisher(Float64, 'sensor_3', 10)
        self.timer = self.create_timer(3.0, self.publish_sensor_data)

    def publish_sensor_data(self):
        msg = Float64()
        msg.data = round(random.uniform(0.0, 10.0), 1)  # Solo una decimal
        self.publisher.publish(msg)
        self.get_logger().info(f'[Sensor 3] Publicando: {msg.data}')

def main(args=None):
    rclpy.init(args=args)
    sensor3 = Sensor3Publisher()
    rclpy.spin(sensor3)
    sensor3.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()