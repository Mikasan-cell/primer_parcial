import rclpy
from rclpy.node import Node
from std_msgs.msg import Float64
import random

class Sensor2Publisher(Node):
    def __init__(self):
        super().__init__('Nodo2')
        self.publisher = self.create_publisher(Float64, 'sensor_2', 10)
        self.timer = self.create_timer(3.0, self.publish_sensor_data)

    def publish_sensor_data(self):
        msg = Float64()
        msg.data = round(random.uniform(0.0, 10.0), 1)
        self.publisher.publish(msg)
        self.get_logger().info(f'[Sensor 2] Publicando: {msg.data}')

def main(args=None):
    rclpy.init(args=args)
    sensor2 = Sensor2Publisher()
    rclpy.spin(sensor2)
    sensor2.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()