import rclpy
from rclpy.node import Node
from ucb_interface.srv import Kinematics  # Mensaje de servicio personalizado
import sympy as sp

class KinematicsServer(Node):
    def __init__(self):
        super().__init__('kinematics_server')  # 🔥 Se agrega correctamente el nombre del nodo

        # Definir servicio
        self.srv = self.create_service(Kinematics, 'compute_kinematics', self.compute_kinematics_callback)
        self.get_logger().info("Kinematics Server is ready.")

        # Definir variables simbólicas
        self.th1, self.th2, self.th3, self.L1, self.L2 = sp.symbols('th1 th2 th3 L1 L2')

        # Definir matrices de transformación
        self.Ry1 = sp.Matrix([
            [sp.cos(-self.th1), 0, sp.sin(-self.th1), 0],
            [0, 1, 0, 0],
            [-sp.sin(-self.th1), 0, sp.cos(-self.th1), 0],
            [0, 0, 0, 1]
        ])

        self.Rx1 = sp.Matrix([
            [1, 0, 0, 0],
            [0, sp.cos(self.th2), -sp.sin(self.th2), 0],
            [0, sp.sin(self.th2), sp.cos(self.th2), 0],
            [0, 0, 0, 1]
        ])

        self.Tz1 = sp.Matrix([
            [1, 0, 0, 0],
            [0, 1, 0, 0],
            [0, 0, 1, -self.L1],
            [0, 0, 0, 1]
        ])

        self.Ry2 = sp.Matrix([
            [sp.cos(-self.th3), 0, sp.sin(-self.th3), 0],
            [0, 1, 0, 0],
            [-sp.sin(-self.th3), 0, sp.cos(-self.th3), 0],
            [0, 0, 0, 1]
        ])

        self.Tz2 = sp.Matrix([
            [1, 0, 0, 0],
            [0, 1, 0, 0],
            [0, 0, 1, -self.L2],
            [0, 0, 0, 1]
        ])

        # Calcular la matriz M
        self.M = self.Ry1 * self.Rx1 * self.Tz1 * self.Ry2 * self.Tz2

        # Calcular posición final
        self.M_simplified = sp.simplify(self.M * sp.Matrix([0, 0, 0, 1]))
        self.get_logger().info("Transformation matrix computed.")

    def compute_kinematics_callback(self, request, response):
        # Convertir ángulos de grados a radianes
        theta1_rad = request.theta1 * (sp.pi / 180)
        theta2_rad = request.theta2 * (sp.pi / 180)
        theta3_rad = request.theta3 * (sp.pi / 180)

        # Sustituir valores numéricos en la ecuación simbólica
        M_numeric = self.M_simplified.subs({
            self.th1: theta1_rad,
            self.th2: theta2_rad,
            self.th3: theta3_rad,
            self.L1: 69.5,  # mm
            self.L2: 71.5   # mm
        })

        # Extraer valores finales
        response.pose.position.x = float(M_numeric[0])
        response.pose.position.y = float(M_numeric[1])
        response.pose.position.z = float(M_numeric[2])

        self.get_logger().info(f"Computed position: x={response.pose.position.x}, y={response.pose.position.y}, z={response.pose.position.z}")
        return response

def main(args=None):
    rclpy.init(args=args)
    node = KinematicsServer()
    rclpy.spin(node)
    rclpy.shutdown()

if __name__ == '__main__':
    main()
