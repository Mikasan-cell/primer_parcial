import rclpy
from rclpy.node import Node
from std_msgs.msg import String

class MiNodoSuscriptor(Node):
    def __init__(self):
        super().__init__('nodo_suscriptor')
        self.subscription = self.create_subscription(
            String, 'miki', self.listener_callback, 10)  # Se suscribe al tópico "miki"
        self.subscription  

    def listener_callback(self, msg):
        valores_str = msg.data.replace("Valores binarios: ", "").strip()  # Extrae los valores binarios
        valores = eval(valores_str)  # Convierte la cadena en una lista de enteros

        if isinstance(valores, list) and len(valores) == 3:
            estado, motores = self.obtener_estado_y_motores(valores)  # Obtiene el estado y los motores
            mi, md = motores  # Extrae valores de los motores
            self.get_logger().info(f'Recibido: {valores} -> Estado: {estado}, Motores: MI={mi}, MD={md}')
        else:
            self.get_logger().warn(f'Mensaje no válido: {msg.data}')

    def obtener_estado_y_motores(self, valores):
        """ Determina el estado del robot y el estado de los motores basado en la tabla """
        si, sc, sd = valores

        # Tabla de estados con motores
        tabla = {
            (0, 0, 0): ("Adelante", (1, 1)),
            (0, 0, 1): ("Derecha", (0, 1)),
            (0, 1, 0): ("Alto", (0, 0)),
            (0, 1, 1): ("Derecha", (0, 1)),
            (1, 0, 0): ("Izquierda", (1, 0)),
            (1, 0, 1): ("Adelante", (1, 1)),
            (1, 1, 0): ("Izquierda", (1, 0)),
            (1, 1, 1): ("Alto", (0, 0))
        }

        return tabla.get((si, sc, sd), ("Estado desconocido", (None, None)))

def main(args=None):
    rclpy.init(args=args)
    nodo_suscriptor = MiNodoSuscriptor()
    try:
        rclpy.spin(nodo_suscriptor)
    except KeyboardInterrupt:
        pass
    finally:
        nodo_suscriptor.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()
