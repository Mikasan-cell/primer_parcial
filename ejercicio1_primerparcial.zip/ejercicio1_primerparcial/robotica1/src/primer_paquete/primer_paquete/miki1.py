import rclpy  # Librería de ROS 2
from rclpy.node import Node  # Clase base para nodos en ROS 2
from std_msgs.msg import String  # Tipo de mensaje estándar de ROS 2
import random  # Para generar valores aleatorios

class MiNodoPublicador(Node):
    def __init__(self):
        super().__init__('nodo_publicador')  # Nombre del nodo
        self.publisher = self.create_publisher(String, 'miki', 10)  # Publicador en el tópico 'miki'
        time_period = 3.0  # Intervalo de publicación en segundos (cada 3s)
        self.timer = self.create_timer(time_period, self.timer_callback)  # Temporizador
        self.i = 0  # Contador de mensajes

    def timer_callback(self):
        valores_binarios = [random.randint(0, 1) for _ in range(3)]  # Genera 3 valores binarios (0 o 1)
        msg = String()
        msg.data = f'Valores binarios: {valores_binarios}'  # Convierte la lista a string
        self.publisher.publish(msg)  # Publica el mensaje
        self.get_logger().info(f'Publicando: "{msg.data}"')  # Muestra el mensaje en consola
        self.i += 1  # Incrementa el contador de mensajes

def main(args=None):
    rclpy.init(args=args)  # Inicializa ROS 2
    minodo = MiNodoPublicador()  # Crea el nodo
    try:
        rclpy.spin(minodo)  # Mantiene el nodo en ejecución
    except KeyboardInterrupt:
        pass
    finally:
        minodo.destroy_node()  # Destruye el nodo antes de salir
        rclpy.shutdown()  # Apaga ROS 2

if __name__ == '__main__':
    main()
